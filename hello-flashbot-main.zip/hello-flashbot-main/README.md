# hello-flashbot

```shell
npm i

cp .env.example .env

npx ts-node src/index.ts
```

WasteGas `0x26C4ca34f722BD8fD23D58f34576d8718c883A80`
